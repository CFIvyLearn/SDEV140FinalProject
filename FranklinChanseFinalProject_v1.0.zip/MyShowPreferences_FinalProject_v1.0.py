#Final GUI Project: Your Show Preferences
#Chanse Franklin

#import from breezy
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from tkinter import PhotoImage, N, S, W, E
from tkinter.font import Font
from breezypythongui import EasyFrame
from statistics import multimode
#sets parallel lists for user inputted data. No option for deleting data.
showList = []
scoreList = []
episodeLength = []
yearList = []
genreList = []
ratingList = []
studioList = []
class ShowPref(EasyFrame):
    #initializes group of parallel lists to hold data about every show

    def __init__(self):
        #initializes window and widgets
        EasyFrame.__init__(self, title = "Your Show Preferences")
        self.label1 = self.addLabel(text = "Enter the show's name: ", row = 0,
                      column = 0, columnspan = 2)
        self.show = self.addTextField(text = "", row = 0, column = 2, columnspan = 1)
        self.showAdd = self.addButton(text = "Add", row = 1, column = 0,
                       columnspan = 1, command = self.addShow)
        self.done = self.addButton(text = "Done", row = 1, column = 1, columnspan = 1,
                                   command = self.calculations, state = "disabled")
        self.exit = self.addButton(text = "Exit", row = 1, column = 2,
                       columnspan = 1, command = self.optionClose)
        #Creates an image with alt text 
        self.imageLabel = self.addLabel(text = "",
                              row = 2, column = 1,
                              sticky = N+S+W+E)
        self.altText = self.addLabel(text = "The world of shows!",
                                row = 3, column = 1,
                                sticky = N+S+W+E)

        self.image = PhotoImage(file = "tv.png")
        self.imageLabel["image"] = self.image

        font = Font(family = "Calibri", size = 16, slant = "italic")
        self.altText["font"] = font
        self.altText["foreground"] = "orange"
        self.fromDisplay = False
        

    def addShow(self):
        #Retrieves input from text field, validates it, and then either adds to list or displays error
        newShow = self.show.get()
        showOK = self.strValidate(newShow)
        if showOK:
            showList.append(newShow)
            self.secondScreen()
        else:
            messagebox.showerror(title=None, message='Show name is empty')

    def strValidate(self, showName):
        #validates all string inputs or displays an error. Returns boolean value.
        if showName:
            try:
                str(showName)
                return True
            except ValueError:
                messagebox.showerror(title=None, message='Show needs to be a string input')
                return False
        else:
            return False

    def intValidate(self, showNum):
        #validates all integer inputs or displays an error. Returns boolean value.
        if showNum:
            return True
        else:
            return False       

    def optionClose(self):
        #opens an extra validation box to make sure the user wants to quit, then destroys the window.
        answer = messagebox.askokcancel(title = None, message = "Are you sure you want to quit?")
        if answer:
            self.master.destroy()
                
    def secondScreen(self):
        #destroys every label, button, field, image, or text on the first screen
        self.label1.destroy()
        self.show.destroy()
        self.showAdd.destroy()
        self.done.destroy()
        self.exit.destroy()
        self.imageLabel.destroy()
        self.altText.destroy()
        #initializes layout for second screen
        self.label1 = self.addLabel(text = "Enter your score from 1 to 10",
                      row = 0, column = 0)
        self.score = self.addIntegerField(value = 0, row = 0, column = 1)
        self.label2 = self.addLabel(text = "Enter the number of episodes",
                      row = 1, column = 0)
        self.episodes = self.addIntegerField(value = 0, row = 1, column = 1)
        self.label3 = self.addLabel(text = "What year did the show release?",
                         row = 2, column = 0)
        self.year = self.addIntegerField(value = 0, row = 2, column = 1)
        self.label4 = self.addLabel(text = "What genre of show is it? ex: drama, action, mystery",
                      row = 3, column = 0)
        self.genre = self.addTextField(text = "", row = 3, column = 1)
        self.label5 = self.addLabel(text = "Enter the age rating of the show",
                          row = 4, column = 0)
        self.rating = self.addTextField(text = "", row = 4, column = 1)
        self.label6 = self.addLabel(text = "Enter the studio who made the show",
                      row = 5, column = 0)
        self.studio = self.addTextField(text = "", row = 5, column = 1)
        self.showAdd = self.addButton(text = "Add", row = 6, column = 0,
                       columnspan = 1, command = self.addInfo)
        self.exit = self.addButton(text = "Exit", row = 6, column = 1,
                       columnspan = 1, command = self.optionClose)

    def addInfo(self):
        #Sets boolean to false for nested try-except and if-else structure
        inputIsValid = False
        #Checks for which section of the program the user is arriving from
        #If from displayData, the on screen elements from that module must be destroyed.
        #fromDisplay must be reset to False, and inputIsValid must be set to true
        if self.fromDisplay:
            self.label1.destroy()
            self.label2.destroy()
            self.label3.destroy()
            self.label4.destroy()
            self.label5.destroy()
            self.label6.destroy()
            self.show.destroy()
            self.showAdd.destroy()
            self.exit.destroy()
            self.imageLabel.destroy()
            self.altText.destroy()
            self.fromDisplay = False
            inputIsValid = True

        #Set to else so users coming from displayData skip the input validation done for secondScreen
        else:
            #each field on secondScreen must be validated or show an error message
            try:
                newScore = self.score.getNumber()
                scoreOK = self.intValidate(newScore)
                #checks to make sure score is between 1 and 10
                if newScore in range(1,11) and scoreOK:
                    scoreList.append(newScore)
                    try:
                        newEpisodes = self.episodes.getNumber()
                        episodesOK = self.intValidate(newEpisodes)
                        if episodesOK:
                            episodeLength.append(newEpisodes)
                            try:
                                newYear = self.year.getNumber()
                                yearOK = self.intValidate(newYear)
                                if yearOK:
                                    #try statements end here, since all values here on are string values.
                                    #before, entering a string into an int field threw a ValueError
                                    yearList.append(newYear)
                                    newGenre = self.genre.get()
                                    genreOK = self.strValidate(newGenre)
                                    if genreOK:
                                        genreList.append(newGenre)
                                        newRating = self.rating.get()
                                        ratingOK = self.strValidate(newRating)
                                        if ratingOK:
                                            ratingList.append(newRating)
                                            newStudio = self.studio.get()
                                            studioOK = self.strValidate(newStudio)
                                            if studioOK:
                                                studioList.append(newStudio)
                                                inputIsValid = True

                                                self.label1.destroy()
                                                self.label2.destroy()
                                                self.label3.destroy()
                                                self.label4.destroy()
                                                self.label5.destroy()
                                                self.label6.destroy()
                                                self.show.destroy()
                                                self.showAdd.destroy()
                                                self.exit.destroy()
                                                self.score.destroy()
                                                self.episodes.destroy()
                                                self.year.destroy()
                                                self.genre.destroy()
                                                self.rating.destroy()
                                                self.studio.destroy()
                                    
                                            else:
                                                messagebox.showerror(title=None, message='Studio was not filled in')
                                                #These collections of pop statements remove appended values from lists that will be appended again when the missed value is correctly input
                                                episodeLength.pop()
                                                scoreList.pop()
                                                yearList.pop()
                                                genreList.pop()
                                                ratingList.pop()
                                        else:
                                            messagebox.showerror(title=None, message='Rating was not filled in')
                                            #These collections of pop statements remove appended values from lists that will be appended again when the missed value is correctly input
                                            episodeLength.pop()
                                            scoreList.pop()
                                            yearList.pop()
                                            genreList.pop()
                                    else:
                                        messagebox.showerror(title=None, message='Genre was not filled in')
                                        #These collections of pop statements remove appended values from lists that will be appended again when the missed value is correctly input
                                        episodeLength.pop()
                                        scoreList.pop()
                                        yearList.pop()
                                else:
                                    messagebox.showerror(title=None, message='Year was not filled in')
                                    #These collections of pop statements remove appended values from lists that will be appended again when the missed value is correctly input
                                    episodeLength.pop()
                                    scoreList.pop()
                            except ValueError:
                                messagebox.showerror(title=None, message='Year needs to be an integer input')
                                #These collections of pop statements remove appended values from lists that will be appended again when the missed value is correctly input
                                episodeLength.pop()
                                scoreList.pop()
                        else:
                            messagebox.showerror(title=None, message='Episodes was not filled in')
                            #These collections of pop statements remove appended values from lists that will be appended again when the missed value is correctly input
                            scoreList.pop()
                    except ValueError:
                        messagebox.showerror(title=None, message='Episodes needs to be an integer input')
                        #These collections of pop statements remove appended values from lists that will be appended again when the missed value is correctly input
                        scoreList.pop()
                else:
                    messagebox.showerror(title=None, message='Score must be a number between 1 and 10')
                    #These collections of pop statements remove appended values from lists that will be appended again when the missed value is correctly input
            except ValueError:
                messagebox.showerror(title=None, message='Score needs to be an integer input')
                
        #If the input validation is complete, this initializes the first screen again, but allows the user to hit "Done"
        if inputIsValid:
            self.label1 = self.addLabel(text = "Enter the show's name: ", row = 0,
                      column = 0, columnspan = 2)
            self.show = self.addTextField(text = "", row = 0, column = 2, columnspan = 1)
            self.showAdd = self.addButton(text = "Add", row = 1, column = 0,
                                      columnspan = 1, command = self.addShow)
            self.done = self.addButton(text = "Done", row = 1, column = 1, columnspan = 1,
                                   command = self.calculations)
            self.exit = self.addButton(text = "Exit", row = 1, column = 2,
                                   columnspan = 1, command = self.optionClose)
            self.imageLabel = self.addLabel(text = "",
                              row = 2, column = 1,
                              sticky = N+S+W+E)
            self.altText = self.addLabel(text = "Add some more!",
                                    row = 3, column = 1,
                                    sticky = N+S+W+E)

            self.image = PhotoImage(file = "tv.png")
            self.imageLabel["image"] = self.image

            font = Font(family = "Calibri", size = 16, slant = "italic")
            self.altText["font"] = font
            self.altText["foreground"] = "orange"
            
    def calculations(self):
        #Utilizing lists and the multimode function, this module performs calculations on the user entered data
        scoreAvg = sum(scoreList)/len(scoreList)
        roundedScore = round(scoreAvg, 2)
        episodeAvg = sum(episodeLength)/len(episodeLength)
        roundedEp = round(episodeAvg, 2)
        yearAvg = sum(yearList)/len(yearList)
        roundedYr = round(yearAvg)
        popGenre = multimode(genreList)
        popRating = multimode(ratingList)
        popStudio = multimode(studioList)
        self.displayData(roundedScore, roundedEp, roundedYr, popGenre, popRating, popStudio)

    def displayData(self, scoreAvg, episodeAvg, yearAvg, popGenre, popRating, popStudio):
        #destroys labels, buttons, images, text fields, and text from the first screen
        self.label1.destroy()
        self.show.destroy()
        self.showAdd.destroy()
        self.done.destroy()
        self.exit.destroy()
        self.altText.destroy()
        self.imageLabel.destroy()
        #sets trigger boolean to True, and displays calculations
        self.fromDisplay = True
        self.label1 = self.addLabel(text = "Your average score rating is: " + str(scoreAvg), row = 0,
                     column = 0)
        self.label2 = self.addLabel(text = "Your average number of episodes is: " + str(episodeAvg), row = 1,
                      column = 0)
        self.label3 = self.addLabel(text = "The average year of your shows is: " + str(yearAvg), row = 2,
                      column = 0)
        self.label4 = self.addLabel(text = "Your most-watched genre is: " + str(popGenre)[1:-1], row = 3,
                      column = 0)
        self.label5 = self.addLabel(text = "The most popular age rating for your shows is: " + str(popRating)[1:-1], row = 4,
                      column = 0)
        self.label6 = self.addLabel(text = "Your most-watched studio is: " + str(popStudio)[1:-1], row = 5,
                      column = 0)
        self.showAdd = self.addButton(text = "Add More Shows", row = 6, column = 0, columnspan = 1,
                                       command = self.addInfo)
        self.exit = self.addButton(text = "Exit", row = 6, column = 1,
                                   columnspan = 1, command = self.optionClose)
        #Another section of image creation with alt text
        self.imageLabel = self.addLabel(text = "",
                              row = 7, column = 0,
                              columnspan = 2, sticky = N+S+W+E)
        self.altText = self.addLabel(text = "Those are some cool stats!",
                                row = 8, column = 0,
                                columnspan = 2, sticky = N+S+W+E)

        self.image = PhotoImage(file = "data.png")
        self.imageLabel["image"] = self.image

        font = Font(family = "Calibri", size = 16, slant = "italic")
        self.altText["font"] = font
        self.altText["foreground"] = "purple"

ShowPref().mainloop()
