#Final GUI Project: Your Show Preferences
#Chanse Franklin

#import from breezy
from breezypythongui import EasyFrame
from statistics import multimode

showList = []
scoreList = []
episodeLength = []
yearList = []
genreList = []
ratingList = []
studioList = []
class ShowPref(EasyFrame):
    #initializes group of parallel lists to hold data about every show

    def __init__(self):
        #initializes window and widgets
        EasyFrame.__init__(self, title = "Your Show Preferences")
        self.label1 = self.addLabel(text = "Enter the show's name: ", row = 0,
                      column = 0)
        self.show = self.addTextField(text = "", row = 0, column = 1)
        self.showAdd = self.addButton(text = "Add", row = 1, column = 0,
                       columnspan = 1, command = self.addShow)
        self.done = self.addButton(text = "Done", row = 1, column = 1, columnspan = 1,
                                   command = self.calculations, state = "disabled")
        self.exit = self.addButton(text = "Exit", row = 1, column = 2,
                       columnspan = 1, command = self.quit)
        self.fromDisplay = False
        

    def addShow(self):
        newShow = self.show.get()
        showList.append(newShow)
        self.secondScreen()

    def remove(self):
        self.label1.destroy()
        self.label2.destroy()
        self.label3.destroy()
        self.label4.destroy()
        self.label5.destroy()
        self.label6.destroy()
        self.show.destroy()
        self.showAdd.destroy()
        self.done.destroy()
        self.exit.destroy()
        self.score.destroy()
        self.episodes.destroy()
        self.year.destroy()
        self.genre.destroy()
        self.rating.destroy()
        self.studio.destroy()

    def quit(self):
        self.master.destroy()
                
    def secondScreen(self):
        self.label1.destroy()
        self.show.destroy()
        self.showAdd.destroy()
        self.done.destroy()
        self.exit.destroy()
        
        self.label1 = self.addLabel(text = "Enter your score from 1 to 10",
                      row = 0, column = 0)
        self.score = self.addIntegerField(value = 0, row = 0, column = 1)
        self.label2 = self.addLabel(text = "Enter the number of episodes",
                      row = 1, column = 0)
        self.episodes = self.addIntegerField(value = 0, row = 1, column = 1)
        self.label3 = self.addLabel(text = "What year did the show release?",
                         row = 2, column = 0)
        self.year = self.addIntegerField(value = 0, row = 2, column = 1)
        self.label4 = self.addLabel(text = "What genre of show is it? ex: drama, action, mystery",
                      row = 3, column = 0)
        self.genre = self.addTextField(text = "", row = 3, column = 1)
        self.label5 = self.addLabel(text = "Enter the age rating of the show",
                          row = 4, column = 0)
        self.rating = self.addTextField(text = "", row = 4, column = 1)
        self.label6 = self.addLabel(text = "Enter the studio who made the show",
                      row = 5, column = 0)
        self.studio = self.addTextField(text = "", row = 5, column = 1)
        self.showAdd = self.addButton(text = "Add", row = 6, column = 0,
                       columnspan = 1, command = self.addInfo)
        self.exit = self.addButton(text = "Exit", row = 6, column = 1,
                       columnspan = 1, command = self.quit)

    def addInfo(self):
        if self.fromDisplay:
            self.label1.destroy()
            self.label2.destroy()
            self.label3.destroy()
            self.label4.destroy()
            self.label5.destroy()
            self.label6.destroy()
            self.show.destroy()
            self.showAdd.destroy()
            self.exit.destroy()
            self.fromDisplay = False

        else:        
            newScore = self.score.getNumber()
            scoreList.append(newScore)
            newEpisodes = self.episodes.getNumber()
            episodeLength.append(newEpisodes)
            newYear = self.year.getNumber()
            yearList.append(newYear)
            newGenre = self.genre.get()
            genreList.append(newGenre)
            newRating = self.rating.get()
            ratingList.append(newRating)
            newStudio = self.studio.get()
            studioList.append(newStudio)

            self.label1.destroy()
            self.label2.destroy()
            self.label3.destroy()
            self.label4.destroy()
            self.label5.destroy()
            self.label6.destroy()
            self.show.destroy()
            self.showAdd.destroy()
            self.exit.destroy()
            self.score.destroy()
            self.episodes.destroy()
            self.year.destroy()
            self.genre.destroy()
            self.rating.destroy()
            self.studio.destroy()
        
        self.label1 = self.addLabel(text = "Enter the show's name: ", row = 0,
                      column = 0)
        self.show = self.addTextField(text = "", row = 0, column = 1)
        self.showAdd = self.addButton(text = "Add", row = 1, column = 0,
                                      columnspan = 1, command = self.addShow)
        self.done = self.addButton(text = "Done", row = 1, column = 1, columnspan = 1,
                                   command = self.calculations)
        self.exit = self.addButton(text = "Exit", row = 1, column = 2,
                                   columnspan = 1, command = self.quit)
            
    def calculations(self):
        scoreAvg = sum(scoreList)/len(scoreList)
        episodeAvg = sum(episodeLength)/len(episodeLength)
        yearAvg = sum(yearList)/len(yearList)
        popGenre = multimode(genreList)
        popRating = multimode(ratingList)
        popStudio = multimode(studioList)
        self.displayData(scoreAvg, episodeAvg, yearAvg, popGenre, popRating, popStudio)

    def displayData(self, scoreAvg, episodeAvg, yearAvg, popGenre, popRating, popStudio):
        self.label1.destroy()
        self.show.destroy()
        self.showAdd.destroy()
        self.done.destroy()
        self.exit.destroy()

        self.fromDisplay = True
        self.label1 = self.addLabel(text = "Your average score rating is: " + str(scoreAvg), row = 0,
                     column = 0)
        self.label2 = self.addLabel(text = "Your average number of episodes is: " + str(episodeAvg), row = 1,
                      column = 0)
        self.label3 = self.addLabel(text = "The average year of your shows is: " + str(yearAvg), row = 2,
                      column = 0)
        self.label4 = self.addLabel(text = "Your most-watched genre is: " + str(popGenre)[1:-1], row = 3,
                      column = 0)
        self.label5 = self.addLabel(text = "The most popular age rating for your shows is: " + str(popRating)[1:-1], row = 4,
                      column = 0)
        self.label6 = self.addLabel(text = "Your most-watched studio is: " + str(popStudio)[1:-1], row = 5,
                      column = 0)
        self.showAdd = self.addButton(text = "Add More Shows", row = 6, column = 0, columnspan = 1,
                                       command = self.addInfo)
        self.exit = self.addButton(text = "Exit", row = 6, column = 1,
                                   columnspan = 1, command = self.quit)

ShowPref().mainloop()
